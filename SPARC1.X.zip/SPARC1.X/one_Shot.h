/* 
 * File:   one_Shot.h
 * Author: mausa
 *
 * Created on 20 de noviembre de 2019, 04:59 PM
 */

#ifndef ONE_SHOT_H
#define	ONE_SHOT_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ONE_SHOT_H */

